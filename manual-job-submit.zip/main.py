import json
import os
import logging
import subprocess
from google.cloud import pubsub_v1, storage
from google.cloud.video.transcoder_v1 import TranscoderServiceClient
from google.auth.transport.requests import Request
import google.auth

# Set up logging
logger = logging.getLogger("transcoder_logger")
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
logger.addHandler(handler)


def transcode_handler(request):
    try:
        # Parse request JSON
        request_json = request.get_json(silent=True)
        if not request_json:
            return {
                "statusCode": 400,
                "message": "Invalid input. Request body must be JSON."
            }, 400

        source_bucket_name = "vodunprocessedgcp"
        destination_bucket_name = "vodprocessedgcp"

        # Initialize storage client
        storage_client = storage.Client()
        source_bucket = storage_client.bucket(source_bucket_name)
        destination_bucket = storage_client.bucket(destination_bucket_name)

        # Fetch the most recent object from the source bucket
        blobs = list(storage_client.list_blobs(source_bucket))
        if not blobs:
            return {
                "statusCode": 404,
                "message": "No files found in the source bucket."
            }, 404

        latest_blob = max(blobs, key=lambda blob: blob.time_created)
        source_gcs_object = latest_blob.name
        source_gcs = f"gs://{source_bucket_name}/{source_gcs_object}"
        file_name = os.path.basename(source_gcs_object)
        base_file_name = os.path.splitext(file_name)[0]

        logger.info(f"Latest file selected for transcoding: {source_gcs}")

        # Copy the original video to the destination bucket, maintaining folder structure and correct naming
        original_blob_path = f"{base_file_name}_original.mp4"
        new_blob_name = f"{base_file_name}/video/{original_blob_path}"  # Create the new path in destination bucket
        blob_copy = source_bucket.copy_blob(latest_blob, destination_bucket, new_blob_name)
        logger.info(f"Copied original file to destination bucket as {blob_copy.name}")


        # Transcoder job setup
        client = TranscoderServiceClient()
        parent = f"projects/verse-dev-433901/locations/us-east4"

        job = {
            "input_uri": source_gcs,
            "output_uri": f"gs://{destination_bucket_name}/{base_file_name}/video/",
            "config": {
                "elementary_streams": [
                    {
                        "key": "sd_video_stream",
                        "video_stream": {
                            "h264": {
                                "width_pixels": 854,
                                "height_pixels": 480,
                                "bitrate_bps": 2_000_000,
                                "frame_rate": 30.0
                            }
                        }
                    },
                    {
                        "key": "hd_video_stream",
                        "video_stream": {
                            "h264": {
                                "width_pixels": 1280,
                                "height_pixels": 720,
                                "bitrate_bps": 6_000_000,
                                "frame_rate": 60.0
                            }
                        }
                    },
                    {
                        "key": "uhd_video_stream",
                        "video_stream": {
                            "h264": {
                                "width_pixels": 1920,
                                "height_pixels": 1080,
                                "bitrate_bps": 50_000_000,
                                "frame_rate": 90.0,
                                "profile": "high"
                            }
                        }
                    },
                    {
                        "key": "audio_stream",
                        "audio_stream": {
                            "codec": "aac",
                            "bitrate_bps": 128_000,
                            "channel_count": 2,
                            "sample_rate_hertz": 48000
                        }
                    }
                ],
                "mux_streams": [
                    {
                        "key": f"{base_file_name}_sd",
                        "container": "mp4",
                        "elementary_streams": ["sd_video_stream", "audio_stream"]
                    },
                    {
                        "key": f"{base_file_name}_hd",
                        "container": "mp4",
                        "elementary_streams": ["hd_video_stream", "audio_stream"]
                    },
                    {
                        "key": f"{base_file_name}_uhd",
                        "container": "mp4",
                        "elementary_streams": ["uhd_video_stream", "audio_stream"]
                    }
                ]
            }
        }

        #create thumbnail

        create_thumbnail(base_file_name)

        # Create the transcoding job
        response = client.create_job(parent=parent, job=job)
        job_name = response.name
        logger.info(f"Transcoding job started: {response}")

        # Notify job completion
        job_completed(file_name)

        return {
            "statusCode": 200,
            "message": f"Transcoding job started for the latest file: {file_name}",
            "jobName": job_name
        }

    except Exception as error:
        logger.error(f"Error during transcoding: {error}")
        return {
            "statusCode": 500,
            "message": "Transcoding job failed",
            "error": str(error)
        }, 500


def job_completed(file_name):
    try:
        publisher = pubsub_v1.PublisherClient()
        project_id = "verse-dev-433901"
        topic_name = "verse-dev-433901-topic"
        topic_path = publisher.topic_path(project_id, topic_name)

        message = {
            "message": f"The transcoded file '{file_name}' is now available in the destination bucket."
        }
        message_json = json.dumps(message).encode("utf-8")

        future = publisher.publish(topic_path, message_json)
        logger.info(f"Published notification to Pub/Sub: {message_json}")
        return future

    except Exception as e:
        logger.error(f"Error publishing to Pub/Sub: {e}")
        return None


def create_thumbnail(file_name):

    source_bucket_name = "vodunprocessedgcp"
    output_bucket_name = "vodprocessedgcp"
    # video_name = file_name
    # base_file_name = os.path.splitext(file_name)[0]
    output_file_path = f"{file_name}/thumbnail/{file_name}.jpg"  # Changed to .jpg
    
    storage_client = storage.Client()
    
    # Update the download path to avoid nested directories in /tmp
    local_video_path = f"/tmp/{file_name}"
    local_thumbnail_path = "/tmp/thumbnail.jpg"  # Changed to .jpg
    
    # Download the video from the source bucket
    logger.info(f"Starting download of video file: {file_name} from bucket: {source_bucket_name}")
    source_bucket = storage_client.bucket(source_bucket_name)
    blob = source_bucket.blob(f"{file_name}.mp4")
    blob.download_to_filename(local_video_path)
    logger.info(f"Downloaded video to: {local_video_path}")
    
    # FFmpeg command to generate the thumbnail in JPEG format
    command = [
        "ffmpeg",
        "-y",  # Force overwrite for thumbnail generation
        "-loglevel", "error",  # Set log level to error to suppress most logs
        "-i", local_video_path,
        "-ss", "00:00:10",
        "-vframes", "1",
        "-q:v", "2",  # Quality setting, 1 is highest, increase for more compression
        local_thumbnail_path
    ]
    
    subprocess.run(command, check=True)
    logger.info(f"Thumbnail generated at: {local_thumbnail_path}")
    
    # Upload the JPEG thumbnail to the output bucket
    output_bucket = storage_client.bucket(output_bucket_name)
    thumbnail_pic_blob = output_bucket.blob(output_file_path)
    thumbnail_pic_blob.upload_from_filename(local_thumbnail_path)
    logger.info(f"Thumbnail uploaded to bucket '{output_bucket_name}' under: {output_file_path}")

    # Clean up temporary files
    logger.info("Cleaning up temporary files...")
    temp_files = [local_video_path, local_thumbnail_path]
    for temp_file in temp_files:
        try:
            os.remove(temp_file)
            logger.info(f"Removed temporary file: {temp_file}")
        except OSError as e:
            logger.error(f"Error removing temporary file {temp_file}: {e}")