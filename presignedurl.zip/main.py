import os
from google.cloud import storage, secretmanager
from google.oauth2 import service_account
from datetime import datetime
import logging

# Configuration
BUCKET_NAME = "vodprocessedgcp"  # Name of your bucket
SECRET_NAME = "vod-cdn-privatekey"  # Name of the secret in Secret Manager
SERVICE_ACCOUNT_KEY_SECRET_NAME = "service-account-key"  # Secret name for the service account key

def access_secret_version(secret_name):
    """
    Access the latest version of a secret from Secret Manager.
    """
    client = secretmanager.SecretManagerServiceClient()
    secret_path = f"projects/1038404886674/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(request={"name": secret_path})
    return response.payload.data.decode("utf-8")

def generate_signed_url(bucket_name, object_name):
    """
    Generate a Signed URL for a Cloud Storage object with no expiration.
    """
    try:
        # Retrieve the service account key from Secret Manager
        service_account_key = access_secret_version(SERVICE_ACCOUNT_KEY_SECRET_NAME)

        # Convert the service account key (JSON) to credentials
        credentials = service_account.Credentials.from_service_account_info(
            eval(service_account_key)  # Convert the string representation of JSON to a dictionary
        )

        # Initialize the storage client with the provided credentials
        storage_client = storage.Client(credentials=credentials)

        # Get the bucket and object blob
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(object_name)

        # Set an expiration time far in the future
        far_future = datetime(2099, 11, 26)  

        # Generate signed URL
        signed_url = blob.generate_signed_url(
            version="v2",
            expiration=far_future,
            method="GET",
        )
        return signed_url

    except Exception as e:
        logging.error(f"Error generating signed URL: {e}")
        raise

def write_signed_url_to_file(bucket_name, object_name, signed_url):
    """
    Write the Signed URL to a .txt file in the same bucket, 
    removing the original extension from the file name.
    """
    storage_client = storage.Client()  # No need to pass credentials explicitly
    bucket = storage_client.bucket(bucket_name)

    # Remove the original extension and add .txt
    base_name = os.path.splitext(object_name)[0]  # Get the file name without extension
    signed_url_filename = f"{base_name}.txt"  # Add .txt extension

    # Create a blob object for the .txt file
    blob = bucket.blob(signed_url_filename)

    # Write the signed URL to the file
    blob.upload_from_string(signed_url, content_type="text/plain")

    logging.info(f"Signed URL saved to {signed_url_filename}")

def handle_new_object(event, context):
    """
    Cloud Function triggered by a new object upload in Cloud Storage.
    """
    # Log the event for debugging
    logging.info(f"Event ID: {context.event_id}")
    logging.info(f"Event type: {context.event_type}")
    logging.info(f"Bucket: {event.get('bucket')}")
    logging.info(f"File: {event.get('name')}")

    # Extract bucket and object name from the event
    bucket_name = event['bucket']
    object_name = event['name']

    if not bucket_name or not object_name:
        logging.error("Missing bucket or object name in the event payload.")
        raise ValueError("Invalid event payload: 'bucket' and 'name' are required.")

    # List of allowed file extensions
    
    allowed_extensions = ['.mp4', '.vtt', '.json', '.jpeg', '.m4s', '.mpd', '.wav']

    # Only process files with allowed extensions
    if not any(object_name.endswith(ext) for ext in allowed_extensions):
        logging.info(f"Skipping unsupported file: {object_name}")
        return  # Skip processing


    # Retrieve the private key from Secret Manager
    private_key = access_secret_version(SECRET_NAME)

    # Generate the Signed URL
    signed_url = generate_signed_url(bucket_name, object_name)

    # Save the Signed URL to a .txt file in the same bucket
    write_signed_url_to_file(bucket_name, object_name, signed_url)

    logging.info(f"Signed URL for {object_name}: {signed_url}")
