from google.cloud import storage
import os
import re

def log_segment_urls(bucket_name, mpd_object_name):
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    # Read the manifest.mpd content
    mpd_blob = bucket.blob(mpd_object_name)
    mpd_content = mpd_blob.download_as_text()

    # Find all Representation IDs in the manifest
    representation_id_pattern = re.compile(r'<Representation id="(\d+)"')
    representation_ids = representation_id_pattern.findall(mpd_content)

    if not representation_ids:
        print("No representation IDs found.")
        return

    print(f"Found Representation IDs: {representation_ids}")

    # Find and log segment URLs for each representation
    for representation_id in representation_ids:
        print(f"\nProcessing Representation ID: {representation_id}")

        # Search for all segments based on the RepresentationID and segment numbers
        for segment_number in range(0, 100):  # Adjust the range if required
            segment_txt_file = f"{os.path.dirname(mpd_object_name)}/segment-{representation_id}-{segment_number}.txt"
            segment_txt_blob = bucket.blob(segment_txt_file)

            if segment_txt_blob.exists():
                pre_signed_url = segment_txt_blob.download_as_text().strip()
                print(f"Segment-{representation_id}-{segment_number} URL: {pre_signed_url}")
            else:
                pass
                # print(f"Segment-{representation_id}-{segment_number}.txt not found.")

def handler(data, context):

    """
    Cloud Function handler triggered when a GCS object is created or updated.
    """
    bucket_name = data['bucket']
    object_name = data['name']

    print(f"Triggered by: {object_name} in bucket: {bucket_name}")

    if object_name.endswith('manifest.mpd') and not object_name.startswith('updated'):
        log_segment_urls(bucket_name, object_name)
        print("Processing complete.")
