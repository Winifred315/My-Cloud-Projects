import json
import os
import logging
import subprocess
from google.cloud import pubsub_v1
from google.cloud import speech
from google.cloud.video.transcoder_v1 import TranscoderServiceClient
from google.cloud import storage

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# def copy_original_file(source_bucket_name, source_file_name, destination_bucket_name, destination_file_name):
#     """Copies a file from one GCS bucket to another with specified naming."""
#     storage_client = storage.Client()

#     source_bucket = storage_client.bucket(source_bucket_name)
#     source_blob = source_bucket.blob(source_file_name)

#     destination_bucket = storage_client.bucket(destination_bucket_name)

#     try:
#         logger.info(f"Copying file from {source_bucket_name}/{source_file_name} to {destination_bucket_name}/{destination_file_name}...")
#         source_bucket.copy_blob(source_blob, destination_bucket, destination_file_name)
#         logger.info(f"File copied successfully to {destination_bucket_name}/{destination_file_name}.")
#     except Exception as e:
#         logger.error(f"Error copying file: {e}")
#         raise


def handler(event, context=None):
    pass

#     logger.info(f"Event: {json.dumps(event)}")

#     source_gcs_bucket = event['bucket']
#     source_gcs_object = event['name']
#     source_gcs = f"gs://{source_gcs_bucket}/{source_gcs_object}"
#     file_name = os.path.basename(source_gcs_object)
#     base_file_name = os.path.splitext(file_name)[0]
    
#     logger.info("The source file path is %s", source_gcs)
       
#     # Define original file path in the destination bucket
#     original_blob_path = f"{base_file_name}-original.mp4"
#     destination_path = f"{base_file_name}/video/{original_blob_path}"

#     # Copy the original file to the destination bucket
#     copy_original_file(
#         source_bucket_name=source_gcs_bucket,
#         source_file_name=source_gcs_object,
#         destination_bucket_name="vodprocessedgcp",
#         destination_file_name=destination_path
#     )

#     # Transcoder job
#     client = TranscoderServiceClient()
#     parent = f"projects/verse-dev-433901/locations/us-east4"

#     job = {
#         "input_uri": source_gcs,
#         "output_uri": f"gs://vodprocessedgcp/{base_file_name}/video/",
#         "config": {
#             "elementary_streams": [
#                 {
#                     "key": "sd_video_stream",
#                     "video_stream": {
#                         "h264": {
#                             "width_pixels": 854,
#                             "height_pixels": 480,
#                             "bitrate_bps": 2_000_000,
#                             "frame_rate": 30.0
#                         }
#                     }
#                 },
#                 {
#                     "key": "hd_video_stream",
#                     "video_stream": {
#                         "h264": {
#                             "width_pixels": 1280,
#                             "height_pixels": 720,
#                             "bitrate_bps": 6_000_000,
#                             "frame_rate": 60.0,
#                             "profile": "high"
#                         }
#                     }
#                 },
#                 {
#                     "key": "uhd_video_stream",
#                     "video_stream": {
#                         "h264": {
#                             "width_pixels": 1920,
#                             "height_pixels": 1080,
#                             "bitrate_bps": 50_000_000,
#                             "frame_rate": 90.0,
#                             "profile": "high"
#                         }
#                     }
#                 },
#                 {
#                     "key": "audio_stream",
#                     "audio_stream": {
#                         "codec": "aac",
#                         "bitrate_bps": 128_000,
#                         "channel_count": 2,  # Adjust if necessary
#                         "sample_rate_hertz": 48000
#                     }
#                 }
#             ],
#             "mux_streams": [
#                 {
#                     "key": f"{base_file_name}-sd_output",
#                     "container": "mp4",
#                     "elementary_streams": ["sd_video_stream", "audio_stream"]
#                 },
#                 {
#                     "key": f"{base_file_name}-hd_output",
#                     "container": "mp4",
#                     "elementary_streams": ["hd_video_stream", "audio_stream"]
#                 },
#                 {
#                     "key": f"{base_file_name}-uhd_output",
#                     "container": "mp4",
#                     "elementary_streams": ["uhd_video_stream", "audio_stream"]
#                 }
#             ]
#         }
#     }

#     #create thumbnail

#     create_thumbnail(base_file_name)

#     try:
#         # Attempt to create the transcoding job
#         response = client.create_job(parent=parent, job=job)
#         job_name = response.name
#         logger.info(response)

#         job_completed(base_file_name)

#     except Exception as error:
#         logger.error('Exception: %s', error)
#         return {
#             'statusCode': 500,
#             'resultCode': 'Failed',
#             'resultString': str(error)
#         }


# def job_completed(file_name):
#     publisher = pubsub_v1.PublisherClient()
#     project_id = 'verse-dev-433901'
#     topic_name = 'verse-dev-433901-topic'
#     topic_path = publisher.topic_path(project_id, topic_name)

#     logger.info(f"Publishing message to existing topic: {topic_path}")

#     try:
#         message = {
#             'message': f'A new video file "{file_name}" has been created in the destination bucket.'
#         }
#         message_json = json.dumps(message).encode('utf-8')

#         future = publisher.publish(topic_path, message_json)
#         logger.info(f'Published message to topic "{topic_name}": {message_json}')

#         return future

#     except Exception as e:
#         logger.error(f'Error publishing to topic "{topic_name}": {e}')
#         return None

# def create_thumbnail(file_name):

#     source_bucket_name = "vodunprocessedgcp"
#     output_bucket_name = "vodprocessedgcp"
#     # video_name = file_name
#     # base_file_name = os.path.splitext(file_name)[0]
#     output_file_path = f"{file_name}/thumbnail/{file_name}.jpg"  # Changed to .jpg
    
#     storage_client = storage.Client()
    
#     # Update the download path to avoid nested directories in /tmp
#     local_video_path = f"/tmp/{file_name}"
#     local_thumbnail_path = "/tmp/thumbnail.jpg"  # Changed to .jpg
    
#     # Download the video from the source bucket
#     logger.info(f"Starting download of video file: {file_name} from bucket: {source_bucket_name}")
#     source_bucket = storage_client.bucket(source_bucket_name)
#     blob = source_bucket.blob(f"{file_name}.mp4")
#     blob.download_to_filename(local_video_path)
#     logger.info(f"Downloaded video to: {local_video_path}")
    
#     # FFmpeg command to generate the thumbnail in JPEG format
#     command = [
#         "ffmpeg",
#         "-y",  # Force overwrite for thumbnail generation
#         "-loglevel", "error",  # Set log level to error to suppress most logs
#         "-i", local_video_path,
#         "-ss", "00:00:10",
#         "-vframes", "1",
#         "-q:v", "2",  # Quality setting, 1 is highest, increase for more compression
#         local_thumbnail_path
#     ]
    
#     subprocess.run(command, check=True)
#     logger.info(f"Thumbnail generated at: {local_thumbnail_path}")
    
#     # Upload the JPEG thumbnail to the output bucket
#     output_bucket = storage_client.bucket(output_bucket_name)
#     thumbnail_pic_blob = output_bucket.blob(output_file_path)
#     thumbnail_pic_blob.upload_from_filename(local_thumbnail_path)
#     logger.info(f"Thumbnail uploaded to bucket '{output_bucket_name}' under: {output_file_path}")

#     # Clean up temporary files
#     logger.info("Cleaning up temporary files...")
#     temp_files = [local_video_path, local_thumbnail_path]
#     for temp_file in temp_files:
#         try:
#             os.remove(temp_file)
#             logger.info(f"Removed temporary file: {temp_file}")
#         except OSError as e:
#             logger.error(f"Error removing temporary file {temp_file}: {e}")